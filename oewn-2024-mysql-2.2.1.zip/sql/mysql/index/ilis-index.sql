ALTER TABLE `ilis` ADD CONSTRAINT `pk_ilis` PRIMARY KEY (`synsetid`);
