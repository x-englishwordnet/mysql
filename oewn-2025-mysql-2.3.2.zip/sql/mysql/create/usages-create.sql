CREATE TABLE `usages` (
`usageid` INT NOT NULL,
`usagenote` MEDIUMTEXT NOT NULL,
`synsetid` INT NOT NULL,
`luid` INT DEFAULT NULL,
`wordid` INT DEFAULT NULL
)
DEFAULT CHARSET=utf8mb4;
