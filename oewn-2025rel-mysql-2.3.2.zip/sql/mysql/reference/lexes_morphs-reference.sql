ALTER TABLE `lexes_morphs` ADD CONSTRAINT `fk_lexes_morphs_luid` FOREIGN KEY (`luid`) REFERENCES `lexes` (`luid`);
ALTER TABLE `lexes_morphs` ADD CONSTRAINT `fk_lexes_morphs_wordid` FOREIGN KEY (`wordid`) REFERENCES `words` (`wordid`);
ALTER TABLE `lexes_morphs` ADD CONSTRAINT `fk_lexes_morphs_morphid` FOREIGN KEY (`morphid`) REFERENCES `morphs` (`morphid`);
ALTER TABLE `lexes_morphs` ADD CONSTRAINT `fk_lexes_morphs_posid` FOREIGN KEY (`posid`) REFERENCES `poses` (`posid`);
