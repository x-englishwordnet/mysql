CREATE TABLE `domains` (
`domainid` INT NOT NULL,
`domain` VARCHAR(32) NOT NULL,
`domainname` VARCHAR(32) NOT NULL,
`posid` ENUM('n','v','a','r','s') NOT NULL
)
DEFAULT CHARSET=utf8mb4;
