CREATE TABLE `poses` (
`posid` ENUM('n','v','a','r','s') NOT NULL,
`pos` VARCHAR(20) NOT NULL
)
DEFAULT CHARSET=utf8mb4;
