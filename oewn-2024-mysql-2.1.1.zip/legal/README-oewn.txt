This includes
- the Open English Wordnet (OEWN) 2021 database.

