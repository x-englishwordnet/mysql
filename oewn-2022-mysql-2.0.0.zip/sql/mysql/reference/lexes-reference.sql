ALTER TABLE `lexes` ADD CONSTRAINT `fk_lexes_posid` FOREIGN KEY (`posid`) REFERENCES `poses` (`posid`);
ALTER TABLE `lexes` ADD CONSTRAINT `fk_lexes_wordid` FOREIGN KEY (`wordid`) REFERENCES `words` (`wordid`);
ALTER TABLE `lexes` ADD CONSTRAINT `fk_lexes_casedwordid` FOREIGN KEY (`casedwordid`) REFERENCES `casedwords` (`casedwordid`);
