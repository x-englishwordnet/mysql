ALTER TABLE `senses_adjpositions` ADD CONSTRAINT `fk_senses_adjpositions_synsetid` FOREIGN KEY (`synsetid`) REFERENCES `synsets` (`synsetid`);
ALTER TABLE `senses_adjpositions` ADD CONSTRAINT `fk_senses_adjpositions_luid` FOREIGN KEY (`luid`) REFERENCES `lexes` (`luid`);
ALTER TABLE `senses_adjpositions` ADD CONSTRAINT `fk_senses_adjpositions_wordid` FOREIGN KEY (`wordid`) REFERENCES `words` (`wordid`);
ALTER TABLE `senses_adjpositions` ADD CONSTRAINT `fk_senses_adjpositions_positionid` FOREIGN KEY (`positionid`) REFERENCES `adjpositions` (`positionid`);
