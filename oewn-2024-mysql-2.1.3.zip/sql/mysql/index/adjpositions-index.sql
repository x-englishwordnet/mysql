ALTER TABLE `adjpositions` ADD CONSTRAINT `pk_adjpositions` PRIMARY KEY (`positionid`);
