CREATE TABLE `lexes` (
`luid` INT NOT NULL,
`posid` ENUM('n','v','a','r','s') NOT NULL,
`wordid` INT NOT NULL,
`casedwordid` INT NULL
);
