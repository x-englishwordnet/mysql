ALTER TABLE `synsets` ADD CONSTRAINT `fk_synsets_posid` FOREIGN KEY (`posid`) REFERENCES `poses` (`posid`);
ALTER TABLE `synsets` ADD CONSTRAINT `fk_synsets_domainid` FOREIGN KEY (`domainid`) REFERENCES `domains` (`domainid`);
