ALTER TABLE `semrelations` ADD CONSTRAINT `pk_semrelations` PRIMARY KEY (`synset1id`,`synset2id`,`relationid`);
ALTER TABLE `semrelations` ADD KEY `k_semrelations_relationid` (`relationid`);
ALTER TABLE `semrelations` ADD KEY `k_semrelations_synset1id` (`synset1id`);
ALTER TABLE `semrelations` ADD KEY `k_semrelations_synset2id` (`synset2id`);
