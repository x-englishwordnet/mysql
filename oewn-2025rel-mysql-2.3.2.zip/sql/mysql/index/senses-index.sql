ALTER TABLE `senses` ADD CONSTRAINT `pk_senses` PRIMARY KEY (`senseid`);
ALTER TABLE `senses` ADD CONSTRAINT `uk_senses_sensekey` UNIQUE KEY (`sensekey`);
ALTER TABLE `senses` ADD CONSTRAINT `uk_senses_luid_sensekey` UNIQUE KEY (`luid`,`sensekey`);
ALTER TABLE `senses` ADD CONSTRAINT `uk_senses_luid_synsetid` UNIQUE KEY (`luid`,`synsetid`);
ALTER TABLE `senses` ADD KEY `k_senses_luid` (`luid`);
ALTER TABLE `senses` ADD KEY `k_senses_wordid` (`wordid`);
ALTER TABLE `senses` ADD KEY `k_senses_casedwordid` (`casedwordid`);
ALTER TABLE `senses` ADD KEY `k_senses_synsetid` (`synsetid`);
