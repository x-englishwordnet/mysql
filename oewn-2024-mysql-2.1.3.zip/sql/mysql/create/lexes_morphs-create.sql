CREATE TABLE `lexes_morphs` (
`luid` INT NOT NULL,
`wordid` INT NOT NULL,
`posid` ENUM('n','v','a','r','s') NOT NULL,
`morphid` INT NOT NULL
);
