ALTER TABLE `lexrelations` ADD CONSTRAINT `fk_lexrelations_synset1id` FOREIGN KEY (`synset1id`) REFERENCES `synsets` (`synsetid`);
ALTER TABLE `lexrelations` ADD CONSTRAINT `fk_lexrelations_synset2id` FOREIGN KEY (`synset2id`) REFERENCES `synsets` (`synsetid`);
ALTER TABLE `lexrelations` ADD CONSTRAINT `fk_lexrelations_relationid` FOREIGN KEY (`relationid`) REFERENCES `relations`(`relationid`);
ALTER TABLE `lexrelations` ADD CONSTRAINT `fk_lexrelations_lu1id` FOREIGN KEY (`lu1id`) REFERENCES `lexes` (`luid`);
ALTER TABLE `lexrelations` ADD CONSTRAINT `fk_lexrelations_lu2id` FOREIGN KEY (`lu2id`) REFERENCES `lexes` (`luid`);
ALTER TABLE `lexrelations` ADD CONSTRAINT `fk_lexrelations_word1id` FOREIGN KEY (`word1id`) REFERENCES `words` (`wordid`);
ALTER TABLE `lexrelations` ADD CONSTRAINT `fk_lexrelations_word2id` FOREIGN KEY (`word2id`) REFERENCES `words` (`wordid`);
