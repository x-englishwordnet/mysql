ALTER TABLE `ilis` ADD CONSTRAINT `fk_ilis_synsetid` FOREIGN KEY (`synsetid`) REFERENCES `synsets` (`synsetid`);
