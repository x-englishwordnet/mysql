ALTER TABLE `senses_vframes` ADD CONSTRAINT `fk_senses_vframes_synsetid` FOREIGN KEY (`synsetid`) REFERENCES `synsets` (`synsetid`);
ALTER TABLE `senses_vframes` ADD CONSTRAINT `fk_senses_vframes_luid` FOREIGN KEY (`luid`) REFERENCES `lexes` (`luid`);
ALTER TABLE `senses_vframes` ADD CONSTRAINT `fk_senses_vframes_wordid` FOREIGN KEY (`wordid`) REFERENCES `words` (`wordid`);
ALTER TABLE `senses_vframes` ADD CONSTRAINT `fk_senses_vframes_frameid` FOREIGN KEY (`frameid`) REFERENCES `vframes` (`frameid`);
