ALTER TABLE `casedwords` ADD CONSTRAINT `fk_casedwords_wordid` FOREIGN KEY (`wordid`) REFERENCES `words` (`wordid`);
