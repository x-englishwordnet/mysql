ALTER TABLE `lexes` ADD CONSTRAINT `pk_lexes` PRIMARY KEY (`luid`);
ALTER TABLE `lexes` ADD KEY `k_lexes_wordid` (`wordid`);
ALTER TABLE `lexes` ADD KEY `k_lexes_casedwordid` (`casedwordid`);
