ALTER TABLE `lexes_pronunciations` ADD CONSTRAINT `fk_lexes_pronunciations_luid` FOREIGN KEY (`luid`) REFERENCES `lexes` (`luid`);
ALTER TABLE `lexes_pronunciations` ADD CONSTRAINT `fk_lexes_pronunciations_wordid` FOREIGN KEY (`wordid`) REFERENCES `words` (`wordid`);
ALTER TABLE `lexes_pronunciations` ADD CONSTRAINT `fk_lexes_pronunciations_pronunciationid` FOREIGN KEY (`pronunciationid`) REFERENCES `pronunciations` (`pronunciationid`);
ALTER TABLE `lexes_pronunciations` ADD CONSTRAINT `fk_lexes_pronunciations_posid` FOREIGN KEY (`posid`) REFERENCES `poses` (`posid`);
