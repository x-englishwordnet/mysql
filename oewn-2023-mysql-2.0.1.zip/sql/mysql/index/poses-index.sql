ALTER TABLE `poses` ADD CONSTRAINT `pk_poses` PRIMARY KEY (`posid`);
