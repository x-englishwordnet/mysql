CREATE TABLE `semrelations` (
`synset1id` INT NOT NULL,
`synset2id` INT NOT NULL,
`relationid` INT NOT NULL
);
