ALTER TABLE `relations` ADD CONSTRAINT `pk_relations` PRIMARY KEY (`relationid`);
ALTER TABLE `relations` ADD CONSTRAINT `uk_relations_relation` UNIQUE KEY (`relation`);
