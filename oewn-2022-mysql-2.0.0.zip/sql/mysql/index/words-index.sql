ALTER TABLE `words` ADD CONSTRAINT `pk_words` PRIMARY KEY (`wordid`);
ALTER TABLE `words` ADD CONSTRAINT `uk_words_word` UNIQUE KEY (`word`);
