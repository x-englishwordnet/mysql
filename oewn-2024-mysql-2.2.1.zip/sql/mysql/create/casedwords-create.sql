CREATE TABLE `casedwords` (
`casedwordid` INT NOT NULL,
`wordid` INT NOT NULL ,
`casedword` VARCHAR(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs NOT NULL
)
DEFAULT CHARSET=utf8mb4;
