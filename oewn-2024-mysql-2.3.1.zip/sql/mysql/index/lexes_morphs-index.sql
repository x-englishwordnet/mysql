ALTER TABLE `lexes_morphs` ADD CONSTRAINT `pk_lexes_morphs` PRIMARY KEY (`morphid`,`luid`,`posid`);
ALTER TABLE `lexes_morphs` ADD KEY `k_lexes_morphs_morphid` (`morphid`);
ALTER TABLE `lexes_morphs` ADD KEY `k_lexes_morphs_luid` (`luid`);
ALTER TABLE `lexes_morphs` ADD KEY `k_lexes_morphs_wordid` (`wordid`);
