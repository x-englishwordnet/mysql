ALTER TABLE `vtemplates` ADD CONSTRAINT `pk_vtemplates` PRIMARY KEY (`templateid`);
ALTER TABLE `vtemplates` ADD CONSTRAINT `uk_vtemplates_template` UNIQUE KEY (`template`(64));
