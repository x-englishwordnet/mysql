ALTER TABLE `samples` ADD CONSTRAINT `fk_samples_synsetid` FOREIGN KEY (`synsetid`) REFERENCES `synsets` (`synsetid`);
ALTER TABLE `samples` ADD CONSTRAINT `fk_samples_luid` FOREIGN KEY (`luid`) REFERENCES `lexes` (`luid`);
ALTER TABLE `samples` ADD CONSTRAINT `fk_samples_wordid` FOREIGN KEY (`wordid`) REFERENCES `words` (`wordid`);
