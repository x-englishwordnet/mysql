ALTER TABLE `semrelations` ADD CONSTRAINT `fk_semrelations_synset1id` FOREIGN KEY (`synset1id`) REFERENCES `synsets` (`synsetid`);
ALTER TABLE `semrelations` ADD CONSTRAINT `fk_semrelations_synset2id` FOREIGN KEY (`synset2id`) REFERENCES `synsets` (`synsetid`);
ALTER TABLE `semrelations` ADD CONSTRAINT `fk_semrelations_relationid` FOREIGN KEY (`relationid`) REFERENCES `relations`(`relationid`);
