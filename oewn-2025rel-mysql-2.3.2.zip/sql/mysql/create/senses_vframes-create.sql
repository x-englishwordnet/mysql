CREATE TABLE `senses_vframes` (
`synsetid` INT NOT NULL,
`luid` INT NOT NULL,
`wordid` INT NOT NULL,
`frameid` INT NOT NULL
);
