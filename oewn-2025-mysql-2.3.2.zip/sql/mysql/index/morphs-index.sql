ALTER TABLE `morphs` ADD CONSTRAINT `pk_morphs` PRIMARY KEY (`morphid`);
ALTER TABLE `morphs` ADD CONSTRAINT `uk_morphs_morph` UNIQUE KEY (`morph`);
