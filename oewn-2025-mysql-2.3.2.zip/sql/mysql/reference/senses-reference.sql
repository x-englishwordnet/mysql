ALTER TABLE `senses` ADD CONSTRAINT `fk_senses_luid` FOREIGN KEY (`luid`) REFERENCES `lexes` (`luid`);
ALTER TABLE `senses` ADD CONSTRAINT `fk_senses_wordid` FOREIGN KEY (`wordid`) REFERENCES `words` (`wordid`);
ALTER TABLE `senses` ADD CONSTRAINT `fk_senses_casedwordid` FOREIGN KEY (`casedwordid`) REFERENCES `casedwords` (`casedwordid`);
ALTER TABLE `senses` ADD CONSTRAINT `fk_senses_synsetid` FOREIGN KEY (`synsetid`) REFERENCES `synsets` (`synsetid`);
