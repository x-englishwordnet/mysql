ALTER TABLE `wikidatas` ADD CONSTRAINT `pk_wikidatas` PRIMARY KEY (`synsetid`);
