ALTER TABLE `vframes` ADD CONSTRAINT `pk_vframes` PRIMARY KEY (`frameid`);
ALTER TABLE `vframes` ADD CONSTRAINT `uk_vframes_frame` UNIQUE KEY (`frame`);
