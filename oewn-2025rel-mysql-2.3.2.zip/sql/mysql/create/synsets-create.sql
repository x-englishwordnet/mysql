CREATE TABLE `synsets` (
`synsetid` INT NOT NULL,
`posid` ENUM('n','v','a','r','s') NOT NULL,
`domainid` INT NOT NULL,
`definition` MEDIUMTEXT NOT NULL
 )
DEFAULT CHARSET=utf8mb4;
