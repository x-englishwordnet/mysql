ALTER TABLE `synsets` ADD CONSTRAINT `pk_synsets` PRIMARY KEY (`synsetid`);
