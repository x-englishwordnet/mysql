CREATE TABLE `adjpositions` (
`positionid` ENUM('a','p','ip') NOT NULL,
`position` VARCHAR(24) NOT NULL
)
DEFAULT CHARSET=utf8mb4;
