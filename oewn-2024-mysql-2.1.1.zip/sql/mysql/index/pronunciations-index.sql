ALTER TABLE `pronunciations` ADD CONSTRAINT `pk_pronunciations` PRIMARY KEY (`pronunciationid`);
ALTER TABLE `pronunciations` ADD CONSTRAINT `uk_pronunciations_pronunciation` UNIQUE KEY (`pronunciation`);
