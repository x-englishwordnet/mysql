ALTER TABLE `usages` ADD CONSTRAINT `pk_usages` PRIMARY KEY (`synsetid`,`usageid`);
ALTER TABLE `usages` ADD KEY `k_usages_synsetid` (`synsetid`);
ALTER TABLE `usages` ADD KEY `k_usages_luid` (`luid`);
ALTER TABLE `usages` ADD KEY `k_usages_wordid` (`wordid`);
