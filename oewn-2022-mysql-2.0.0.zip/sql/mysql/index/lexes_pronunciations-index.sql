ALTER TABLE `lexes_pronunciations` ADD KEY `k_lexes_pronunciations_pronunciationid` (`pronunciationid`);
ALTER TABLE `lexes_pronunciations` ADD KEY `k_lexes_pronunciations_luid` (`luid`);
ALTER TABLE `lexes_pronunciations` ADD KEY `k_lexes_pronunciations_wordid` (`wordid`);
