ALTER TABLE `domains` ADD CONSTRAINT `pk_domains` PRIMARY KEY (`domainid`);
ALTER TABLE `domains` ADD CONSTRAINT `uk_domains_domain_posid` UNIQUE KEY (`domain`,`posid`);
