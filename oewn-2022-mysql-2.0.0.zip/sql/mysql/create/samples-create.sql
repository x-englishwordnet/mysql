CREATE TABLE `samples` (
`sampleid` INT NOT NULL,
`sample` MEDIUMTEXT NOT NULL,
`synsetid` INT NOT NULL
)
DEFAULT CHARSET=utf8mb4;
