ALTER TABLE `samples` ADD CONSTRAINT `fk_samples_synsetid` FOREIGN KEY (`synsetid`) REFERENCES `synsets` (`synsetid`);
