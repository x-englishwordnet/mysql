ALTER TABLE `samples` ADD CONSTRAINT `pk_samples` PRIMARY KEY (`synsetid`,`sampleid`);
ALTER TABLE `samples` ADD KEY `k_samples_synsetid` (`synsetid`);
ALTER TABLE `samples` ADD KEY `k_samples_luid` (`luid`);
ALTER TABLE `samples` ADD KEY `k_samples_wordid` (`wordid`);
