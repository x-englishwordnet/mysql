ALTER TABLE `casedwords` ADD CONSTRAINT `pk_casedwords` PRIMARY KEY (`casedwordid`);
ALTER TABLE `casedwords` ADD CONSTRAINT `uk_casedwords_casedword` UNIQUE KEY (`casedword`);
ALTER TABLE `casedwords` ADD KEY `k_casedwords_wordid` (`wordid`);
ALTER TABLE `casedwords` ADD KEY `k_casedwords_wordid_casedwordid` (`wordid`,`casedwordid`);
