ALTER TABLE `usages` ADD CONSTRAINT `fk_usages_synsetid` FOREIGN KEY (`synsetid`) REFERENCES `synsets` (`synsetid`);
ALTER TABLE `usages` ADD CONSTRAINT `fk_usages_luid` FOREIGN KEY (`luid`) REFERENCES `lexes` (`luid`);
ALTER TABLE `usages` ADD CONSTRAINT `fk_usages_wordid` FOREIGN KEY (`wordid`) REFERENCES `words` (`wordid`);
