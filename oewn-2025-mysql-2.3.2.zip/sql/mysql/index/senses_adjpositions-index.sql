ALTER TABLE `senses_adjpositions` ADD KEY `k_senses_adjpositions_synsetid` (`synsetid`);
ALTER TABLE `senses_adjpositions` ADD KEY `k_senses_adjpositions_luid` (`luid`);
ALTER TABLE `senses_adjpositions` ADD KEY `k_senses_adjpositions_wordid` (`wordid`);
