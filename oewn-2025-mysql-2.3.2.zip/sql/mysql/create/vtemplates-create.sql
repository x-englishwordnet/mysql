CREATE TABLE `vtemplates` (
`templateid` INT NOT NULL,
`template` MEDIUMTEXT NOT NULL
)
DEFAULT CHARSET=utf8mb4;
