ALTER TABLE `senses_vtemplates` ADD KEY `k_senses_vtemplates_templateid` (`templateid`);
ALTER TABLE `senses_vtemplates` ADD KEY `k_senses_vtemplates_synsetid` (`synsetid`);
ALTER TABLE `senses_vtemplates` ADD KEY `k_senses_vtemplates_luid` (`luid`);
ALTER TABLE `senses_vtemplates` ADD KEY `k_senses_vtemplates_wordid` (`wordid`);
