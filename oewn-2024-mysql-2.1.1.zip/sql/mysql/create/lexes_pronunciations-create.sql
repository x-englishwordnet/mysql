CREATE TABLE `lexes_pronunciations` (
`luid` INT NOT NULL,
`wordid` INT NOT NULL,
`posid` ENUM('n','v','a','r','s') NOT NULL,
`pronunciationid` INT NOT NULL,
`variety` VARCHAR(2) DEFAULT NULL
);
