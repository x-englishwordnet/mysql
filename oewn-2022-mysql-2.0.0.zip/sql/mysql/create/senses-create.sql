CREATE TABLE `senses` (
`senseid` INT NOT NULL,
`sensekey` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
`synsetid` INT NOT NULL,
`luid` INT NOT NULL,
`wordid` INT NOT NULL,
`casedwordid` INT DEFAULT NULL,
`lexid` INT NOT NULL,
`sensenum` INT DEFAULT NULL,
`tagcount` INT DEFAULT NULL
)
DEFAULT CHARSET=utf8mb4;
