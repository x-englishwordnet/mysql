ALTER TABLE `senses_vframes` ADD KEY `k_senses_vframes_frameid` (`frameid`);
ALTER TABLE `senses_vframes` ADD KEY `k_senses_vframes_synsetid` (`synsetid`);
ALTER TABLE `senses_vframes` ADD KEY `k_senses_vframes_luid` (`luid`);
ALTER TABLE `senses_vframes` ADD KEY `k_senses_vframes_wordid` (`wordid`);
