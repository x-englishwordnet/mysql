ALTER TABLE `wikidatas` ADD CONSTRAINT `fk_wikidatas_synsetid` FOREIGN KEY (`synsetid`) REFERENCES `synsets` (`synsetid`);
