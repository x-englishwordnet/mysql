INSERT INTO poses (posid,pos) VALUES
('a','adjective'),
('n','noun'),
('r','adverb'),
('s','adjective satellite'),
('v','verb');
