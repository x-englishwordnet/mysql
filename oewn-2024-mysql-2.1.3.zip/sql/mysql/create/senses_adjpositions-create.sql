CREATE TABLE `senses_adjpositions` (
`synsetid` INT NOT NULL,
`luid` INT NOT NULL,
`wordid` INT NOT NULL,
`positionid` ENUM('a','p','ip') NOT NULL
);
